import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class CalculatorServer extends CalculatorImpl {
	
	//public CalculatorServer() throws RemoteException{}
	public CalculatorServer() throws RemoteException{
		try {
			Calculator cal = new CalculatorImpl();
			Naming.rebind("rmi://localhost:1099/CalculatorService", cal);
		}catch(Exception e) {
			System.out.println("Trouble: "+e.getMessage());
		}
	}
	public static void main(String[] args) throws RemoteException{
		/*try {
			CalculatorImpl cal = new CalculatorImpl();
			
			Calculator stub = (Calculator) UnicastRemoteObject.exportObject(cal,0);
			Registry registry = LocateRegistry.getRegistry();
			
			registry.bind("Hello", stub);
			System.err.println("Server ready"); 
		}catch (Exception e) { 
	         System.err.println("Server exception: " + e.toString()); 
	         e.printStackTrace(); }
	}*/
		new CalculatorServer();

	}
	
}
