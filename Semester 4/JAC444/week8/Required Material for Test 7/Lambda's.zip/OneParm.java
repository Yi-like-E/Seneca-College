package ca.senecacollege.lambda;

public class OneParm implements MixInter {

	public static void main(String...strings) {
		MixInter onePa = (num)->{
			return num * num;
		};
		MixInter inter = new OneParm();
		
		System.out.println("The mulitplication is: "+onePa.compute(5));
		//System.out.println("This is addition: " + inter.compute(6));
		System.out.println("This is subtration:" + compute((value)->(value-10),20));
		System.out.println("This is addition:" + compute((value)->(value+value),20));
	}

	//@Override
	public static int compute(MixInter obj, int c) {
		return obj.compute(c);
	}
}
