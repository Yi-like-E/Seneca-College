package ca.senecacollege.lambdaexamples;

public class NoParameter implements NoParameterInterface{
	public static void main(String...strings) {
		NoParameterInterface inter = new NoParameter();
		inter.SquareValue(2);
	}
	/*
		NoParameterInterface obj = (x,y)->{
			if((x+y)%2 == 0)
				return true;
			else 
				return false;
		};
		if(obj.evenOrodd(2, 2))
			System.out.println("The number is Even");
		else 
			System.out.println("The number is Odd");
	}*/
		/*NoParameterInterface square = (num) -> {
			return num * num;
			
		};
		
		int val = 100;
		System.out.println("The Square of the value is:" 
				+ square.SquareValue(5));
		
		System.out.println("The Addition of the value is:"+
				SquareValue(value -> (value + value),5));
		
		System.out.println("The Subtraction of the value is:"+
				SquareValue(value -> (value - 10),val));
		
		
	}
	
	public static int SquareValue(NoParameterInterface inter, int v) {
		return inter.SquareValue(v);
	}*/
		/*NoParameterInterface msg = () -> {return "Hello from Lambda";};
		
		System.out.println(msg.Hello());
		
		NoParameterInterface msg1 = new NoParameter();
		System.out.println(msg1.Hello());
	}
	
	@Override
	public String Hello() {
		return "Hello from Normal Interface Implementation";
	}*/

	@Override
	public boolean evenOrodd(int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int SquareValue(int value) {
		// TODO Auto-generated method stub
		return 0;
	}
}
