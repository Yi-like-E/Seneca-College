package ca.senecacollege.lambda;

@FunctionalInterface
public interface MixInter {

	//String Hello();
	//int compute(int c);
	boolean evenorodd(int x, int y);

	//int compute(MixInter obj, int c);
}
