package ca.senecacollege.lambdaexamples;


//@FunctionalInterface
public interface NoParameterInterface {
	public int SquareValue(int value);
	public boolean evenOrodd(int x, int y);
	
}
