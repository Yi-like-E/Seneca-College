import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class UDPServer {
	public static void main(String[] args) {
		try {
			DatagramSocket socket = new DatagramSocket(5000);
			
			while(true) {
				//To accept data from the socket
				byte[] buffer = new byte[50];
				//Datagram Packet to populate whatever received from the socket
				DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
				//impo: socket.receive method doesn't create an into in connection between the server & client
				//which means it doesn't return anything for server to send back to client
				socket.receive(packet); //This method actually blocks until the data is received
				
				System.out.println("Text received is: "+new String(buffer)); 
				//System.out.println("Text received is: "+new String(buffer,0,packet.getLength())); 
				
				
				  /*String returnString = "echo: " + new String(buffer,0,packet.getLength());
				  byte[] buffer2 = returnString.getBytes();
				  InetAddress address = packet.getAddress();
				  int port = packet.getPort();
				  packet = new DatagramPacket(buffer2, buffer2.length, address, port);
				  socket.send(packet);
				 */
			}
			
		}catch(SocketException e) {
			System.out.println("Socket Exception: "+e.getMessage());
		}catch(IOException e) {
			System.out.println("IO Exception: "+e.getMessage());
		}
	}

}
